<?php
// Step 1: Connect to Database
$servername = "localhost:3370";
$username = "root";
$password = "";
$dbname = "pickles";

$connection = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Step 2: Query Data
$cartItemsQuery = "SELECT item_name, SUM(quantity) AS total_quantity, SUM(quantity * price) AS total_sales FROM cart_items GROUP BY item_name";
$cartItemsResult = $connection->query($cartItemsQuery);

// Step 3: Format and Display Report
echo "<h2>Cart Items Report</h2>";
echo "<table border='1'>";
echo "<tr><th>Item Name</th><th>Total Quantity</th><th>Total Sales</th></tr>";
while($row = $cartItemsResult->fetch_assoc()) {
    echo "<tr><td>".$row["item_name"]."</td><td>".$row["total_quantity"]."</td><td>".$row["total_sales"]."</td></tr>";
}
echo "</table>";

// Step 4: Close Connection
$connection->close();
?>
