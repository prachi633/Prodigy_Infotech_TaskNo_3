<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        /* Basic CSS Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styles */
        body {
            font-family: Arial, sans-serif;
            /* background: url('p79');
              background-repeat: no-repeat;
             background-size:cover;
  */
         
           
           
        }
        .section1{
            background-color: aqua;
        }

        /* Sidebar Styles */
        .sidebar {
            height: 100%;
            width: 300px;
            position: fixed;
            top: 0;
            left: 0; 
            padding-top: 50px;
            position:fixed;

            background-color:grey;
            /*background-color: white;
            padding-top: 20px;
            background: linear-gradient(to right, #9976eb, hsl(0, 89%, 80%));
    border-radius: 10px;*/
    

        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        .bar {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            padding: 20px;
            margin-left:40%;
        }
        .section {
            background-color: #f4f4f4;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            margin-right:50%;
            padding: 20px;
            width: 48%;
        }
        .section h2 {
            margin-top: 0;
        }

        .sidebar a {
            padding: 30px 30px;
            text-decoration: none;
            font-size: 18px;
            color: black;
            display: block;
            transition: 0.3s;
            font-weight:bold;
            font-size:17px;
        }

        .sidebar a:hover {
           
            background-color: white;
            transition: background-color 0.3s ease;
           
    border-radius: 10px;
        }

        /* Content Styles */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        /* Responsive Styles */
        @media screen and (max-width: 600px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }

            .content {
                margin-left: 0;
            }
        }
        .logo img {
    width: 100px;
    height: 100px;
    border-radius: 45px;
    margin-left: 20PX;
    outline: 6px solid rgb(218, 23, 23);
  }
  h1{
    color:red;
  }
  button{
    font-size: 2rem;
    padding: 0.6rem 1rem;
    font-weight: bold;
    color: black;
   
    border-radius: 20px;
    box-shadow: rgba(10, 161, 111, 0.2) 0px 7px 29px 0px;
    cursor: pointer;
    border: none;
     position: absolute;
     bottom: 40px;
     margin-left: 40px;
     
  }
  .container {
    margin: 30px;
    padding: 30px;
    border: 2px solid #f1eded;
    border-radius: 5px;
    width: 300px;
    height:300px ;
    text-align: left;
    background-color: #f9f9f9;
    
}

h1 {
    font-size: 24px;
}

form {
    text-align: right;
    
}
h2{
    text-align: center;
}

label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    position: left;
    
    
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 2px solid #ccc;
    border-radius: 5px;
    margin-right: 20%;
}

input[type="submit"] {
    background-color: #333;
    text-align: center;
    color: #fff;
    padding: 50px 60px;
    border: 2px;
    border-radius: 3px;
    cursor: pointer;
    position: center;
}

input[type="submit"]:hover {
    background-color: #555;
}
div{
    
    background: transparent;
    

}
form{
      color: #ebe5e5;
      padding: 100px; 
    background:url('') ;
    background-repeat: no-repeat; 
    background-size: cover;
        
}


.container{
    background: transparent;
    
}

.label{

    padding: 20px;
    
}
h1{
    color: #09035f;
    margin-left: 10%;

}


p{
    font-family: 'sans-serif';
    
    font-display: block;

}
    
    table {
      border-collapse: collapse;
      width: 100%;
      tab-size: 2%;
      
    }

  
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="">
           
          </div>
        <a href="#section1">Dashboard</a>
        <a href="singupreport.php">SignUp Report</a>
        <a href="feedbackreport.php">Feedback Report</a>
        <a href="loginreport.php"> Login Report </a>
        <a href="add.php">Add and Update Product</a>
       
        <button><a href="home.php">Log out</button>
    </div>
    <div class="bar">
        <div class="#section1">
            <h2>Users</h2>
            <?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3370", "root", "","pickles");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Print host information
//echo "Connect Successfully. Host info: " . mysqli_get_host_info($link);

echo'<h1 style="text-align:center;">SingUp Report</h1>     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">';
$sqli = "SELECT * FROM `signup`";
if($result = mysqli_query($link, $sqli)){
    if(mysqli_num_rows($result) > 0){
        

        echo'<table class="table">';
        
            echo "<tr>";
                echo "<th>Id</th>";
                echo "<th>Username</th>";
                echo"<th>Email</th>";
                echo"<th>Password</th>";
                
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['username'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . $row['password'] . "</td>"; 
            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sqli. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>

            <!-- Add user management functionality here -->
            <p>This section could contain functionality for managing users, such as adding, editing, or deleting user accounts.</p>
        </div>
            <!-- Add user management functionality here -->
            <p>This section could contain functionality for managing users, such as adding, editing, or deleting user accounts.</p>
        </div>
</div>
   
        
    
 
    
    
        

       

</body>
</html>

