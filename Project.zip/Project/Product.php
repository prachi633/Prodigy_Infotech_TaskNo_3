<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Veg pickles</title>
    <style>
        
        
/* Reset some default styles for the list */
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
}

.sidebar {
  background-color:black;
  height: 100%;
  width: 250px;
  position: fixed;
  top: 0;
  left: 0;
  font-family: Arial Rounded MT Bold;
  font-weight: bold;
  display: block;
}

.sidebar ul {
  list-style-type: none;
  padding: 5px;
  transition: background-color 0.3s ease;
           
}

.sidebar ul li {
  padding: 15px;

}

.sidebar ul li a {
  color:#f9f4f4;
  text-decoration: none;
  font-size: 25px;
 
    
}



.sidebar ul li a:hover {
  
    background: rgba(239, 241, 242, 0);
    outline: 1px solid rgb(20, 20, 20);
    
    border:2px;
    color: #8bf7f1;
}

.content {
  margin-left: 220px;
  padding: 20px;
}

h1 {
  color: #333;
}

p {
  color: #666;
}


.product {
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;

    
    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;

}

.product img {
    max-width: 100%;
}

.cart {
    border: 1px solid #f3f0f0;
    padding: 20px;
    margin: 10px;
    width: 300px;
    float: right;   
}

.cart ul {
    list-style: none;
    padding: 0;
}

.cart li {
    margin-bottom: 10px;
}
button{
    background-color:skyblue;
    color:white;
font-weigth:bold;
    font-size: medium;
}
p{
    color:rgb(9, 9, 9);
    font-weight: bold;

}
h2,h3{
    font-size:20px;
    color:black;
    font-weight: bold;
}
.section {
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;

    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;
}

.section img {
    max-width: 100%;
}

.main{
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;

    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;

}

.main{
    max-width:100%;
}
.article {
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;

    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;
}

.article img {
    max-width: 100%;
}
.aside {
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;

    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;
    
    
}

.aside img {
    max-width: 100%;
}
.h5{
position: center;
font-size: 100px;
color:black;
float: center;
}
.onion{
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;

    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;
    
}
.onion img{
    max-width: 100%;
}
.coconut{
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;
    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;
    
}
.coconut img{
    
    max-width: 100%;
}

.tomato {
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;
    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;
}
.tomato img{
    max-width: 100%;
}
.lemon{
    border: 2px solid #111111;
    padding: 10px;
    margin-left: 300px;
    text-align: center;
    display: inline-block;
    width: 250px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    background:transparent;
}
.lemon img{
    max-width: 100%;
}
</style>
</head>
<body>
    <h5>Veg Pickles</h5>
    <nav>
        <div class="sidebar">
        <ul>
            <li><a href="#Product">Mango Pickles</a></li>
            <li><a href="#Amala">Amala Pickles</a></li>
            <li><a href="#main">Carrot pickle</a></li>
            <li><a href="#article">Garlic pickle</a></li>
            <li><a href="#aside">Green and Red chili pickle</a></li>
            <li><a href="#onion">Onion pickle</a></li>
            
            <li><a href="#coconut">Coconut pickle</a></li>
            <li><a href="#tomato">Tomato pickle</a></li>
            <li><a href="#lemon">Lemon Pickle</a></li>
        </ul>
        </div>
    </nav>
    
    
    <div class="product">
        <img src="p17.jpg" alt="Product 1">
        <h2>Raw mango pickle</h2>
        <p>150gm</p>
        <h3>Price: 100 rs</h3>
        <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
    </div>
    
    <div class="product">
        <img src="p15.jpg" alt="Product 1">
        <h2>Ram mango pickle</h2>
        <p>200gm</p>
        <h3>Price: 150 rs</h3>
         <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
    </div>


    

    <div class="product">
        <img src="p12.jpg" alt="Product 1">
        <h2>Mango pickle</h2>
        <p>150gm</p>
        <h3>Price: 130 rs</h3>
        <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
    </div>
    <div class="product">
        <img src="p13.jpg" alt="Product 1">
        <h2>Mango pickle</h2>
        <p>200gm</p>
        <h3>Price: 150 rs</h3>
         <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
    </div>
    

    
    <section id="Amala">
        <div class="section">
            <img src="p18.jpg" alt="Product 1">
            <h2>Amla pickle</h2>
            <p>100gm</p>
        <h3>Price: 100 rs</h3>
            <button><a href="Bills.html">Update</a></button>
<button><a href="Bills.html">Delete</a></button>
        </div>
        <div class="section">
            <img src="p19.jpg" alt="Product 1">
            <h2>Amla pickle</h2>
            <p>150gm</p>
        <h3>Price: 120 rs</h3>
             <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
        </div>
        <div class="section">
            <img src="p20.jpg" alt="Product 1">
            <h2>Amla pickle</h2>
            <p>100gm</p>
        <h3>Price: 100 rs</h3>
            <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
</div>
        <div class="section">
            <img src="p21.jpg" alt="Product 1">
            <h2>Amla pickle</h2>
            <p>150gm</p>
        <h3>Price: 80 rs</h3>
              <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
        </div>

        <main id="main">
            <div class="main">
                <img src="p22.jpg" alt="Product 1">
                <h2>Carrot pickle</h2>
                <p>150gm</p>
            <h3>Price: 100 rs</h3>
             <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
            <div class="main">
                <img src="p23.jpg" alt="Product 1">
                <h2>Carrot pickle</h2>
                <p>100gm</p>
            <h3>Price: 80 rs</h3>
             <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
            <div class="main">
                <img src="p24.jpg" alt="Product 1">
                <h2>Carrot pickle</h2>
                <p>100gm</p>
            <h3>Price: 100 rs</h3>
           <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
            <div class="main">
                <img src="p25.jpg" alt="Product 1">
                <h2>Carrot pickle</h2>
                <p>200gm</p>
            <h3>Price: 150 rs</h3>
            <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
        </main>



        <article id="article">
            <div class="article">
                <img src="p26.jpg" alt="Product 1">
                <h2>Garlic pickle</h2>
                <p>100gm</p>
            <h3>Price: 80 rs</h3>
            <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
            <div class="article">
                <img src="p28.jpg" alt="Product 1">
                <h2>Garlic pickle</h2>
                <p>80gm</p>
            <h3>Price: 75 rs</h3>
             <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
            <div class="article">
                <img src="p27.jpg" alt="Product 1">
                <h2>Garlic pickle</h2>
                <p>150gm</p>
            <h3>Price: 100 rs</h3>
            <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
            <div class="article">
                <img src="p29.jpg" alt="Product 1">
                <h2>Garlic pickle</h2>
                <p>150gm</p>
            <h3>Price: 100 rs</h3>
           <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
        </article>

        <aside id="aside">
            <div class="aside">
                <img src="p30.jpg" alt="Product 1">
                <h2>Green chilli pickle</h2>
                <p>150gm</p>
            <h3>Price: 100 rs</h3>
           <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>

            <div class="aside">
            
                <img src="p31.jpg" alt="Product 1">
                <h2>Green chilli pickle</h2>
                <p>100gm</p>
            <h3>Price: 80 rs</h3>
             <button><a href="Bills.html">Update</a></button>
<button><a href="Bills.html">Delete</a></button>
            </div>
             <div class="aside">
                <img src="p32.jpg" alt="Product 1">
                <h2>Red chilli pickle</h2>
                <p>150gm</p>
            <h3>Price: 100 rs</h3>
              <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
            <div class="aside">
                <img src="p33.jpg" alt="Product 1">
                <h2>Red chilli pickle</h2>
                <p>100gm</p>
            <h3>Price: 80 rs</h3>
           <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
            </div>
        </aside>

<onion id="onion">
    <div class="onion">
        <img src="p34.jpg" alt="Product 1">
        <h2>Onion pickle</h2>
        <p>150gm</p>
    <h3>Price: 100 rs</h3>
      <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="onion">
        <img src="p35.jpg" alt="Product 1">
        <h2>Onion pickle</h2>
        <p>80gm</p>
    <h3>Price: 100 rs</h3>
    <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
    </div>
    <div class="onion">
        <img src="p36.jpg" alt="Product 1">
        <h2>Onion pickle</h2>
        <p>150gm</p>
    <h3>Price: 150 rs</h3>
     <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="onion">
        <img src="p37.jpg" alt="Product 1">
        <h2>Onion pickle</h2>
        <p>150gm</p>
    <h3>Price: 100 rs</h3>
 <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
</onion>

<coconut id="coconut">
    <div class="coconut">
        <img src="p38.jpg" alt="Product 1">
        <h2>Coconut pickle</h2>
        <p>150gm</p>
    <h3>Price: 100 rs</h3>
     <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="coconut">
        <img src="p37.jpg" alt="Product 1">
        <h2>Coconut pickle</h2>
        <p>100gm</p>
    <h3>Price: 100 rs</h3>
      <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="coconut">
        <img src="p38.jpg" alt="Product 1">
        <h2>Coconut pickle</h2>
        <p>150gm</p>
    <h3>Price: 150 rs</h3>
      <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
    </div>
    <div class="coconut">
        <img src="p39.jpg" alt="Product 1">
        <h2>Coconut pickle</h2>
        <p>100gm</p>
    <h3>Price: 100 rs</h3>
     <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
</onion>
      
<tomato id="tomato">
    <div class="tomato">
        <img src="p40.jpg" alt="Product 1">
        <h2>Tomato pickle</h2>
        <p>100gm</p>
    <h3>Price: 80 rs</h3>
   <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="tomato">
        <img src="p41.jpg" alt="Product 1">
        <h2>Tomato pickle</h2>
        <p>100gm</p>
    <h3>Price: 100 rs</h3>
      <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="tomato">
        <img src="p42.jpg" alt="Product 1">
        <h2>Tomato pickle</h2>
        <p>100gm</p>
    <h3>Price: 150 rs</h3>
  <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="tomato">
        <img src="p45.jpg" alt="Product 1">
        <h2>Tomato pickle</h2>
        <p>150gm</p>
    <h3>Price: 100 rs</h3>
 <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
</tomato>
        
<lemon id="lemon">
    <div class="lemon">
        <img src="p46.jpg" alt="Product 1">
        <h2>Lemon pickle</h2>
        <p>100gm</p>
    <h3>Price: 80 rs</h3>
 <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="lemon">
        <img src="p47.jpg" alt="Product 1">
        <h2>Lemon pickle</h2>
        <p>150gm</p>
    <h3>Price: 100 rs</h3>
    <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>
    </div>
    <div class="lemon">
        <img src="p48.jpg" alt="Product 1">
        <h2>Lemon pickle</h2>
        <p>150gm</p>
    <h3>Price: 150 rs</h3>
  <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
    <div class="lemon">
        <img src="p49.jpg" alt="Product 1">
        <h2>Lemon pickle</h2>
        <p>150gm</p>
    <h3>Price: 100 rs</h3>
      <button><a href="">Update</a></button>
<button><a href="">Delete</a></button>

    </div>
</tomato>
        



    </body>
    </html>